# Zentrack
ZenTrack is a mobile wellness app for international students to track moods, habits, and notes. Built with React Native and Node.js, it gives personalized mental health tips and breathing exercises. Ideal for daily self-care and emotional awareness.
